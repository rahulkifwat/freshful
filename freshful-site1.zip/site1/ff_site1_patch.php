<?php
// Freshful site update 1: tidy other pages after the new header / footer go in.
//  1. Remove any leftover "compare" button from product cards (other pages).
//  2. Make every page use the ONE Google Maps loader that the new footer provides
//     (a page's own maps script tag is replaced; its callback name is kept).
// Usage: php ff_site1_patch.php <laravelapp> <backup-dir> <layout file> [<layout file> ...]
// Prints: CHANGED <relative path> | INFO ... lines. Safe to run twice.
if (PHP_SAPI !== 'cli') { exit(1); }
$app = rtrim($argv[1] ?? '', '/');
$bk = rtrim($argv[2] ?? '', '/');
$skip = array_map('realpath', array_slice($argv, 3));
if ($app === '' || $bk === '' || !is_dir($app . '/resources/views')) { fwrite(STDERR, "bad arguments\n"); exit(1); }

$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($app . '/resources/views', FilesystemIterator::SKIP_DOTS));
$changed = 0;
foreach ($it as $f) {
    $path = $f->getPathname();
    if (substr($path, -10) !== '.blade.php') { continue; }
    if (in_array(realpath($path), $skip, true)) { continue; }
    $rel = ltrim(substr($path, strlen($app)), '/');
    $c = file_get_contents($path);
    if ($c === false) { continue; }
    $n = $c;
    $notes = [];

    // 1. compare buttons
    if (strpos($n, 'addProductToCompare') !== false) {
        $count = 0;
        $n2 = preg_replace('~[ \t]*<button\b[^>]*addProductToCompare.*?</button>[ \t]*\R?~s', '', $n, -1, $count);
        if ($n2 !== null && $count > 0) { $n = $n2; $notes[] = "compare button removed x$count"; }
        elseif (strpos($n, 'addProductToCompare') !== false) { echo "INFO $rel still mentions addProductToCompare (hidden by CSS)\n"; }
    }
    if (strpos($n, "route('compare_product')") !== false || strpos($n, 'route("compare_product")') !== false) {
        echo "INFO $rel links to the compare page (not removed)\n";
    }

    // 2. Google Maps script tags
    $tag = '~<script\b[^>]*?\bsrc\s*=\s*(["\'])(?:https?:)?//maps\.googleapis\.com/maps/api/js\?(.*?)\1[^>]*>\s*</script>~is';
    if (preg_match_all($tag, $n, $mm, PREG_SET_ORDER)) {
        $n = preg_replace_callback($tag, function ($m) use ($rel, &$notes) {
            $q = $m[2];
            $cb = preg_match('~(?:^|[&?])callback=([A-Za-z_][A-Za-z0-9_]*)~', $q, $x) ? $x[1] : '';
            $libs = preg_match('~libraries=([A-Za-z0-9_,%]+)~', $q, $y) ? urldecode($y[1]) : 'places';
            $parts = array_values(array_unique(array_filter(array_merge(explode(',', $libs), ['places']))));
            $key = preg_match('~(?:^|[&?])key=([^&]*)~', $q, $k) ? $k[1] : '';
            $keyShown = (strpos($key, '{') !== false) ? '(blade expression)' : (strlen($key) > 10 ? substr($key, 0, 8) . '...' : $key);
            if ($cb !== '') {
                $notes[] = "own maps tag replaced (callback $cb, key $keyShown)";
                return "<script>window.__ffMapsCb=(window.__ffMapsCb||[]).concat(['" . $cb . "']);</script>";
            }
            $notes[] = "own maps tag switched to the site key (no callback, key $keyShown)";
            return '<script src="https://maps.googleapis.com/maps/api/js?key={{ config(\'services.google_maps.key\') }}&libraries=' . implode(',', $parts) . '"></script>';
        }, $n);
    } elseif (stripos($n, 'google.maps') !== false) {
        echo "INFO $rel uses google.maps but has no maps script tag (it relies on the footer loader)\n";
    }

    if ($n !== $c && $n !== null) {
        $dest = $bk . '/' . $rel;
        if (!is_dir(dirname($dest))) { mkdir(dirname($dest), 0775, true); }
        if (!is_file($dest)) { copy($path, $dest); }
        file_put_contents($path, $n);
        echo "CHANGED $rel (" . implode('; ', $notes) . ")\n";
        $changed++;
    }
}
echo "DONE changed=$changed\n";
