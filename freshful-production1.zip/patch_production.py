#!/usr/bin/env python3
"""Freshful production update 1 (28 Oct 2026): small anchored additions to 3 existing files.
Changes nothing unless every anchor matches exactly once; keeps each file's own line endings; safe to run twice.
usage: python3 patch_production.py <laravel app folder>"""
import sys, os

root = sys.argv[1]
MARK = 'production update 1'

def load(p):
    b = open(p, 'rb').read().decode('utf-8')
    nl = '\r\n' if '\r\n' in b else '\n'
    return b.replace('\r\n', '\n'), nl

def save(p, s, nl):
    open(p, 'wb').write((s.replace('\n', nl) if nl != '\n' else s).encode('utf-8'))

plans = []

# 1. console page: production menu + styles + script
p = os.path.join(root, 'resources/views/country_console/app.blade.php')
s, nl = load(p)
if MARK not in s:
    a1 = "  $brand = ['country' => ['Freshful Country', 'Pan-India command centre'], 'area' => ['Freshful Area', 'Your hubs command centre'], 'operation' => ['Freshful Operations', 'Operations command centre'], 'admin' => ['Freshful Admin', 'Head office control']][$role] ?? ['Freshful Country', 'Pan-India command centre'];\n"
    ins1 = r"""  /* Production console (production update 1, 28 Oct 2026): production menu, limited to what the production role may open. */
  $prc = null;
  if ($role === 'production' && class_exists(\App\Services\ProductionConsole\ProductionAccess::class)) {
    $brand = ['Freshful Production', 'Production command centre'];
    $prOk = array_flip((array) ($actor['screens'] ?? []));
    $prNav = [
      'Production' => [['pr-home', 'Production dashboard', 'grid'], ['pr-plan', 'Production plan', 'calendar'], ['pr-sheet', 'Production sheet (print)', 'file'], ['pr-batches', 'Dispatches to hubs', 'truck'], ['pr-receipts', 'Hub receipts & differences', 'scale'], ['pr-board', 'Production stock board', 'layers'], ['pr-products', 'Products', 'package']],
      'Inventory management' => [['sheet', 'Hub inventory sheet', 'grid'], ['stock', 'Stock by product', 'package'], ['stock-hubs', 'Stock by hub', 'store'], ['inward', 'Pending inward / accept', 'truck'], ['danger', 'Danger & expired stock', 'clock'], ['ledger', 'Stock ledger', 'history']],
      'Communicator' => [['comm-txn', 'Hub inward / outward transactions', 'history'], ['request', 'Request outward stocks', 'transfer'], ['ihsend', 'InterHub orders (send stock)', 'truck'], ['transfers', 'InterHub moments view', 'pulse']],
      'Wastage' => [['writeoff', 'Write off / spoilage', 'trash'], ['wastage', 'Wastage report', 'chart']],
      'Orders' => [['orders', 'All orders', 'receipt'], ['sched', 'Scheduled orders', 'calendar'], ['cancels', 'Cancellations', 'close']],
      'Customers' => [['customers', 'All customers', 'users'], ['wallets', 'Wallet transactions', 'cash']],
      'Money' => [['cash', 'Cash at hubs', 'cash'], ['reports', 'Sales report', 'filechart']],
      'Delivery boy' => [['riders', 'All delivery boys', 'bike'], ['rider-perf', 'Performance & incentives', 'trophy'], ['rider-add', 'Add delivery boy', 'bike']],
      'Service' => [['grievances', 'Grievances', 'alert']],
    ];
    $nav = [];
    foreach ($prNav as $prG => $prItems) { $prItems = array_values(array_filter($prItems, fn ($x) => isset($prOk[$x[0]]))); if ($prItems) $nav[$prG] = $prItems; }
    $prA = \App\Services\ProductionConsole\ProductionAccess::class;
    $prc = ['screens' => array_keys($prOk), 'role' => $actor['perm_role'] ?? null,
      'colors' => ['Production' => '#0F766E', 'Inventory management' => '#0891B2', 'Communicator' => '#7C3AED', 'Wastage' => '#DC2626', 'Orders' => '#2563EB', 'Customers' => '#DB2777', 'Money' => '#D97706', 'Delivery boy' => '#0D9488', 'Service' => '#E11D48', 'Other' => '#64748B'],
      'can' => ['plan' => $prA::api('pr.plan.save') === null, 'send' => $prA::api('pr.send') === null, 'cancel' => $prA::api('pr.line.cancel') === null, 'toggle' => $prA::api('pr.product.toggle') === null, 'stale' => $prA::api('pr.stale.clear') === null]];
  }
"""
    a2 = "{{-- drivers update 1 --}}<style>{!! file_get_contents(resource_path('views/country_console/assets/dr.css')) !!}</style>\n@endif\n"
    ins2 = "@if ($role === 'production' && file_exists(resource_path('views/country_console/assets/pr.css')))\n{{-- production update 1 --}}<style>{!! file_get_contents(resource_path('views/country_console/assets/pr.css')) !!}</style>\n@endif\n"
    a3 = "<script>{!! file_get_contents(resource_path('views/country_console/assets/cc.js')) !!}</script>\n"
    ins3 = "@if ($role === 'production' && $prc && file_exists(resource_path('views/country_console/assets/pr.js')))\n{{-- production update 1 --}}<script>window.PRC = {!! json_encode($prc, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) !!};</script>\n<script>{!! file_get_contents(resource_path('views/country_console/assets/pr.js')) !!}</script>\n@endif\n"
    for a in (a1, a2, a3):
        if s.count(a) != 1: sys.exit('ANCHOR NOT FOUND in app.blade.php: ' + a[:70])
    s = s.replace(a1, a1 + ins1).replace(a2, a2 + ins2).replace(a3, ins3 + a3)
    plans.append((p, s, nl))

# 2. console script: "All India" label for production too
p = os.path.join(root, 'resources/views/country_console/assets/cc.js')
s, nl = load(p)
old = "var ALL = (C.role === 'country' || C.role === 'admin') ? 'All India' : 'All your hubs';"
new = "var ALL = (C.role === 'country' || C.role === 'admin' || C.role === 'production') ? 'All India' : 'All your hubs'; /* production update 1 */"
if MARK not in s:
    if s.count(old) != 1: sys.exit('ANCHOR NOT FOUND in cc.js')
    plans.append((p, s.replace(old, new), nl))

# 3. routes: one guarded require at the end of web.php
p = os.path.join(root, 'routes/web.php')
s, nl = load(p)
if 'production_console.php' not in s:
    add = "\n// Freshful production console (production update 1, 28 Oct 2026): /production/console\nif (file_exists(__DIR__.'/production_console.php')) { require __DIR__.'/production_console.php'; }\n"
    plans.append((p, s.rstrip('\n') + '\n' + add, nl))

for p, s, nl in plans:
    save(p, s, nl)
    print('patched', os.path.relpath(p, root))
print('PATCH_OK', len(plans))
